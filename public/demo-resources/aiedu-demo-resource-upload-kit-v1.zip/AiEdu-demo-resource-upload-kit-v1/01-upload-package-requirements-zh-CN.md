# 演示教学资源上传包要求

本文用于指导管理员或资源制作方准备可由 AiEdu 演示资源模块直接上传、解析和确认的 ZIP 包。演示资源固定使用 `source_kind=demo_import`、`mode=demo`，不属于 M10 真实资源生成。

## 1. 可直接上传的实例包

- 实例 ZIP：[demo-resource-upload-example-v1.zip](examples/demo-resource-upload-example-v1.zip)
- ZIP 字节数：`904`
- SHA-256：`f014ea5b22e7b0a2f72880faee92768cd692bc7c6faba3e1685193407e9f8e17`
- 推荐解析方式：`manifest_v1`
- 校验结果：`valid=true`，无 issue、无 warning
- canonical hash：`9ee430fb324da708348320145801da2e5157bc6d3087956723e598edb05e9188`

包内结构：

```text
demo-resource-upload-example-v1.zip
├── demo-resource-manifest.json
└── assets/
    └── lesson-1.md
```

源目录也保留在 [minimal-package](examples/minimal-package/)，可以复制后修改并重新打包。

实例包含一门示例课程、一个章节点、一个节节点，以及该节的 A 版 Markdown 讲义。它只用于说明标准格式，不代表正式资源包必须使用相同课程数、目录名、章/节数量或版本结构。

## 2. ZIP 基本要求

| 项目 | 要求 |
| --- | --- |
| 文件格式 | 标准 ZIP；不得上传 RAR、7z、tar 或单个散文件 |
| manifest | 使用 `manifest_v1` 时，ZIP 根目录必须有且只能有一个 `demo-resource-manifest.json` |
| wrapper 目录 | 允许所有文件位于一个共同的一级目录下，例如 `my-package/demo-resource-manifest.json` |
| 文件路径 | 必须是相对路径；禁止绝对路径、盘符路径和 `../` 路径穿越 |
| 特殊文件 | 禁止软链接、设备文件、FIFO、socket 等特殊条目 |
| 重复路径 | 路径规范化后不得重复 |
| 空包 | 不允许 |
| 文件引用 | manifest 引用的文件必须真实存在；建议不保留未引用文件 |

当前仓库默认配置上限如下，部署环境可以配置得更严格，制作方应以目标环境为准：

| 限制 | 默认值 |
| --- | ---: |
| ZIP 大小 | 500 MiB（`524288000` 字节） |
| ZIP 条目数 | 20,000 |
| 解压后总大小 | 2 GiB（`2147483648` 字节） |
| 单文件大小 | 256 MiB（`268435456` 字节） |

服务会同时校验 ZIP 报告大小、对象存储 readback 大小、SHA-256、逐文件大小和解压后总大小，不能依赖伪造的 ZIP header 绕过限制。

## 3. manifest 顶层要求

`demo-resource-manifest.json` 必须是 UTF-8 JSON，且符合 [JSON Schema](schema/demo-resource-manifest.v1.schema.json)。完整示例见 [最小 manifest](examples/minimal-package/demo-resource-manifest.json) 和 [完整 manifest](examples/full-package/demo-resource-manifest.json)。

顶层字段：

| 字段 | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| `schema_version` | string | 是 | 固定为 `demo_resource_package.v1` |
| `package_id` | string | 是 | 包的稳定逻辑标识；不要每次更新都随机生成 |
| `package_revision` | string | 是 | 包修订号，由资源制作方维护 |
| `title` | string | 是 | 包标题 |
| `created_at` | RFC 3339 string | 否 | 制作时间 |
| `courses` | array | 是 | 至少一门目录课程，不得写死为实例包的数量 |

不允许 Schema 未声明的额外字段。若需要资源扩展信息，应放入 variant 的 `metadata` 对象。

## 4. 课程、章和节

课程字段：

| 字段 | 必填 | 说明 |
| --- | --- | --- |
| `external_key` | 是 | 包内稳定且唯一的课程外部键 |
| `title` | 是 | 目录课程名称 |
| `institution` | 否 | 学校或机构名称 |
| `chapters` | 是 | 章数组，可为空 |
| `resource_sets` | 是 | 逻辑资源数组，可为空 |

章和节至少包含 `external_key`、`title`、`order`。同一课程内所有节点的 `external_key` 必须非空且唯一。节放在所属章的 `lessons` 中。

`external_key` 是后续追加、更新和修订识别的核心：

- 同一逻辑对象后续导入时必须保持相同 external key。
- 修改标题、内容或文件不应通过更换 external key 来伪装成新资源。
- `append`/`update` 包没有出现旧资源，不表示删除；删除必须走显式归档/撤回接口。

## 5. 逻辑资源要求

每个 `resource_sets[]` 项包含：

| 字段 | 必填 | 允许值/说明 |
| --- | --- | --- |
| `external_key` | 是 | 当前课程内唯一且稳定 |
| `resource_type` | 是 | 见下方资源类型表 |
| `scope_level` | 是 | `course`、`chapter`、`lesson` |
| `source_node_key` | 是 | 课程级可为空；章/节级必须引用同课程中对应节点 external key |
| `resolution_key` | 是 | 同类资源的解析槽位，例如 `slides`、`mind-map`、`lesson-notes` |
| `resolution_policy` | 是 | `lesson_override` 或 `additive` |
| `title` | 是 | 学生端展示标题 |
| `summary` | 否 | 摘要 |
| `variants` | 是 | 至少一个版本 |

支持的 `resource_type`：

| 值 | 用途 |
| --- | --- |
| `explanation_doc` | 讲义、知识讲解 |
| `extended_reading` | 拓展阅读 |
| `mind_map` | 思维导图 |
| `exercise_set` | 练习题集 |
| `courseware_ppt` | PPTX 课件 |
| `html_animation` | HTML 动画或交互资源 |
| `coding_practice_case` | 编程练习案例 |

层级解析规则：

- `lesson_override`：相同 `resolution_key + variant.code` 时，节级覆盖章级，章级覆盖课程级。
- `additive`：不同层级都保留，不参与覆盖。
- 不同 `resolution_key` 的资源会同时返回。

## 6. A/B/C/D 等版本要求

每个 variant 至少包含：

| 字段 | 必填 | 说明 |
| --- | --- | --- |
| `code` | 是 | 资源内唯一，例如 `A`、`B`、`C`、`D`；不限于四个固定版本 |
| `label` | 否 | 展示名称，例如 `A 版` |
| `content_format` | 是 | 例如 `markdown`、`json`、`pdf`、`pptx`、`html` |
| `asset_kind` | 否 | 资源形态补充标记 |
| `files` | 是 | 至少一个文件声明 |
| `metadata` | 否 | 自定义 JSON 对象 |

版本码区分学生分配结果。一个学生可以得到 0 至 N 个版本；这由发布后的课程分配接口控制，不要为每个学生复制一份资源文件。

## 7. 文件声明与角色

每个 `files[]` 项：

| 字段 | 必填 | 说明 |
| --- | --- | --- |
| `role` | 是 | 见下表 |
| `path` | 是 | ZIP 内相对路径 |
| `mime_type` | 否 | 填写时必须与服务端识别结果兼容 |
| `sha256` | 否 | 64 位十六进制摘要；填写时必须与文件内容一致 |

支持的文件角色：

| role | 要求 |
| --- | --- |
| `primary` | 普通讲义、JSON、PDF、图片等主文件 |
| `primary_pptx` | PPTX 原文件；一个 PPTX variant 必须恰好一个 |
| `preview_pdf` | PPTX 的可选 PDF 预览；最多一个 |
| `entrypoint` | HTML 入口；`html_animation` 必须恰好一个 |
| `supporting` | HTML 的 CSS、JS、图片等相对依赖 |
| `student_payload` | 编程练习的学生可见内容 |
| `reviewer_payload` | 教师/审核内容；学生资源查询不会返回该文件 |

### PPTX 特别要求

- `resource_type` 必须为 `courseware_ppt`。
- `content_format` 必须为 `pptx`。
- PPTX 必须是真实 OOXML 文件，至少包含 `[Content_Types].xml` 和 `ppt/presentation.xml`；不能把其他文件改扩展名伪装成 PPTX。
- 原始 PPTX 使用 `primary_pptx`，学生端作为 `download_url`。
- 有预览 PDF 时使用 `preview_pdf`；没有时 `preview_pdf_url` 返回 `null`，系统不会部署转换器或假装浏览器可预览。

### HTML 特别要求

- `html_animation` 必须有且只有一个 `entrypoint`。
- CSS、JS、图片等使用相对路径并以 `supporting` 声明。
- 包内相对目录会原样保留，避免入口文件的相对引用失效。

## 8. 解析方式要求

管理员上传后必须显式选择解析方式：

| parser | 适用场景 | 是否可应用 |
| --- | --- | --- |
| `manifest_v1` | 本文标准 ZIP，推荐 | 是 |
| `directory_template_v1` | 历史目录，通过管理员提供的正则模板映射 | 是 |
| `manual_mapping` | 管理员提交完整 manifest 和忽略列表 | 是 |
| `auto_detect_preview` | 只预览候选映射 | 否 |

manifest 解析失败后不会静默 fallback。应查看失败 attempt 的 `report_json`，修复包或显式创建新的解析尝试。同一个 ZIP 可以反复解析，无需重新上传。

## 9. 本地打包和校验

从实例源目录重新打包：

```bash
go run ./cmd/demo-resource-validator pack \
  doc/demo-resources/examples/minimal-package \
  /tmp/demo-resource-upload-example-v1.zip
```

校验：

```bash
go run ./cmd/demo-resource-validator validate \
  /tmp/demo-resource-upload-example-v1.zip
```

合格输出至少应包含：

```text
valid manifest_v1 package
"valid": true
"issues": []
```

`warnings` 不一定阻断解析，但正式交付前应逐项确认；例如未引用文件通常意味着 manifest 漏配或包内残留文件。

## 10. 上传实例包的 API 参数

使用本文附带 ZIP 新建导入批次后：

1. 调用 `POST /edu/backend/v1/demo-resources/imports`，请求体为 `{"operation":"create"}`。
2. 调用 `upload-access`，按返回的临时凭证上传 ZIP。
3. 对仓库内附带的原始 ZIP 调用 `complete` 时，请求体为：

```json
{
  "sha256": "f014ea5b22e7b0a2f72880faee92768cd692bc7c6faba3e1685193407e9f8e17",
  "size": 904
}
```

4. 调用 `parse`：

```json
{
  "parser_type": "manifest_v1",
  "parser_config_json": "{}"
}
```

5. 轮询解析尝试并选择成功结果，再查看 diff、确认并 apply。

如果重新打包，ZIP 时间戳等元数据可能改变，必须重新计算实际 ZIP 的 `size` 和 SHA-256，不能继续使用上面的值。

完整接口请求与响应见 [演示资源 API 文档](api.md)。
